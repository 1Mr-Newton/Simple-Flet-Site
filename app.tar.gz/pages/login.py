from flet import *


class Login(Container):
    def __init__(self, page: Page,):
        super().__init__()
        self.expand = True
        self.alignment = alignment.center
        self.bgcolor = 'blue'
        self.content = Column(
            alignment='center',
            horizontal_alignment='center',
            controls=[
                Text(
                    'Welcome back, login page here',
                    size=35
                ),
                Container(
                    content=Text('Home', size=20),
                    bgcolor='green',
                    padding=10,
                    width=100,
                    alignment=alignment.center,
                    on_click=lambda _: page.go('/home')
                ),
                Container(
                    content=Text('About', size=20),
                    bgcolor='brown',
                    padding=10,
                    width=100,
                    alignment=alignment.center,
                    on_click=lambda _: page.go('/about')
                ),
            ]
        )
