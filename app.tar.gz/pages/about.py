from flet import *


class About(Container):
    def __init__(self, page: Page,):
        super().__init__()
        self.expand = True
        self.alignment = alignment.center
        self.bgcolor = 'blue'
        self.content = Column(
            alignment='center',
            horizontal_alignment='center',
            controls=[
                Text(
                    'This is my about',
                    size=35
                ),
                Container(
                    content=Text('Home', size=20),
                    bgcolor='green',
                    padding=10,
                    width=100,
                    alignment=alignment.center,
                    on_click=lambda _: page.go('/home')
                ),
                Container(
                    content=Text('Login', size=20),
                    bgcolor='brown',
                    padding=10,
                    width=100,
                    alignment=alignment.center,
                    on_click=lambda _: page.go('/login')
                ),
            ]
        )
