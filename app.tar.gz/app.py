from flet import *
from pages.home import Home
from pages.about import About
from pages.login import Login


class Main(UserControl):
    def __init__(self, page: Page):
        super().__init__()
        self.page = page

        self.init()

    def init(self,):
        self.page.on_route_change = self.on_route_change
        self.page.go('/login')

    def on_route_change(self, route):
        new_page = {
            '/home': Home,
            '/about': About,
            '/login': Login
        }[self.page.route](self.page)
        self.page.views.clear()
        self.page.views.append(
            View(
                route,
                [new_page]
            )
        )


app(target=Main)
